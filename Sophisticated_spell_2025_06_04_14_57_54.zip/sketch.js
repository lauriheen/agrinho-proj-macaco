var img ;
var img2;
let x =200;
let y =200;
let speed=2;
let jogo= false

function preload(){
  img = loadImage('macaco.png')
}
function setup (){ createCanvas(400,400);
}
function draw() {
  if(jogo==false){
  background(img);
  circle(mouseX,mouseY,10)
  text(mouseX+':'+mouseY,39,20)
  if(mouseX>=151 && mouseY>=180 && mouseX <=240 && mouseY>=210){
    if(mouseIsPressed){
      jogo=true;
    }
  }
  }
  
  
else 
  background(255)
 if (keyIsDown(LEFT_ARROW) && keyIsDown(32)  || keyIsDown(65)  && keyIsDown(32)){
   x -=speed*2;
 } else if(keyIsDown(LEFT_ARROW) || keyIsDown(65)){
    x-=speed;
  }
   if (keyIsDown(RIGHT_ARROW) && keyIsDown(32)  || keyIsDown(68)  && keyIsDown(32)){
   x +=speed*2;
 } else if(keyIsDown(RIGHT_ARROW) || keyIsDown(68)){
    x+=speed;}
  
    if (keyIsDown(UP_ARROW) && keyIsDown(32)  || keyIsDown(87)  && keyIsDown(32)){
   y -=speed*2;
 } else if(keyIsDown(UP_ARROW) || keyIsDown(87)){
    y-=speed;}
    if (keyIsDown(DOWN_ARROW) && keyIsDown(32)  || keyIsDown(83)  && keyIsDown(32)){
   y +=speed*2;
 } else if(keyIsDown(DOWN_ARROW) || keyIsDown(83)){
    y+=speed;
 }
   rect(x,y,30,30)
}

